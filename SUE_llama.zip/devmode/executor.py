import os
import subprocess


class DevExecutor:
    """Dev Mode: run shell commands or Python snippets in sandbox."""

    def __init__(self, cfg: dict):
        self.enabled = cfg.get("enabled", True)
        self.root = cfg.get("sandbox_root", "sandbox")
        os.makedirs(self.root, exist_ok=True)

    def execute(self, cmd: str) -> str:
        if not self.enabled:
            return "DevMode is disabled."

        if cmd.startswith("py "):
            code = cmd[len("py "):]
            return self._run_python(code)
        else:
            return self._run_shell(cmd)

    def _run_shell(self, cmd: str) -> str:
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=self.root,
                capture_output=True,
                text=True
            )
            out = (result.stdout or "") + (result.stderr or "")
            return f"[Dev Shell]\n{out.strip()}"
        except Exception as e:
            return f"[Dev Shell Error] {e}"

    def _run_python(self, code: str) -> str:
        safe_globals = {"__name__": "__dev__"}
        safe_locals = {}
        try:
            exec(code, safe_globals, safe_locals)
            keys = [k for k in safe_locals.keys() if not k.startswith("_")]
            summary = "\n".join(f"{k} = {safe_locals[k]!r}" for k in keys)
            if not summary:
                summary = "(no visible variables)"
            return "[Dev Python]\n" + summary
        except Exception as e:
            return f"[Dev Python Error] {e}"
