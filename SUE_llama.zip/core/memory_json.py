import json
import os
from datetime import datetime


class JsonMemory:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(self.path):
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({"logs": [], "facts": [], "last_rebuild": None}, f)

    def _load(self):
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save(self, data):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def append_log(self, entry: dict):
        data = self._load()
        data["logs"].append(entry)
        self._save(data)

    def save_fact(self, fact: str):
        data = self._load()
        data["facts"].append({
            "fact": fact,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        })
        self._save(data)

    def count_logs(self) -> int:
        data = self._load()
        return len(data.get("logs", []))

    def set_last_rebuild_time(self):
        data = self._load()
        data["last_rebuild"] = datetime.utcnow().isoformat() + "Z"
        self._save(data)

    def get_last_rebuild_time(self):
        data = self._load()
        return data.get("last_rebuild")
