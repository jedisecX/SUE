class WhisperListener:
    """Stub for future Whisper-based STT integration."""

    def __init__(self, settings: dict):
        self.settings = settings

    def listen_once(self) -> str:
        raise NotImplementedError("WhisperListener.listen_once not implemented yet.")

    def listen_loop(self, callback):
        raise NotImplementedError("WhisperListener.listen_loop not implemented yet.")
