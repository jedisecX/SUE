import subprocess


class TTSOutput:
    """TTS output stub; can be wired to ElevenLabs or local TTS."""

    def __init__(self, settings: dict):
        self.settings = settings
        self.provider = settings.get("tts", {}).get("provider", "none")
        self.eleven_key = settings.get("tts", {}).get("elevenlabs_api_key", "")

    def speak(self, text: str):
        if self.provider == "none":
            print(f"[SUE-VOICE] {text}")
            return

        if self.provider == "local-espeak":
            subprocess.run(["espeak", text])
            return

        if self.provider == "elevenlabs":
            print("[SUE-VOICE] (ElevenLabs stub) " + text)
            return

        print(f"[SUE-VOICE] (unknown provider={self.provider}) {text}")
