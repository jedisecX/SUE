import os
from datetime import datetime

from llama_cpp import Llama

from core.memory_json import JsonMemory
from core.memory_vector import VectorMemory
from core.hallucination_filter import HallucinationFilter
from devmode.executor import DevExecutor


class Dispatcher:
    """Core brain loop: routes user input, calls llama.cpp, integrates memory."""

    def __init__(self, settings: dict):
        self.settings = settings
        mem_cfg = settings.get("memory", {})
        self.json_memory = JsonMemory(mem_cfg.get("json_path", "memory/logs.json"))
        self.vector_memory = VectorMemory(
            mem_cfg.get("vector_db_path", "memory/vectors.json"),
            model_path=settings.get("embedding_model", "models/embedding.gguf")
        )
        self.hf = HallucinationFilter(self.json_memory, self.vector_memory)
        self.devmode = DevExecutor(settings.get("devmode", {}))

        model_path = settings.get("model_path", "models/sue.gguf")
        if not os.path.exists(model_path):
            raise RuntimeError(f"SUE model not found at {model_path}. Place a GGUF model there.")

        # initialize llama.cpp main model
        self.llm = Llama(
            model_path=model_path,
            n_ctx=4096,
            n_threads=8,
            n_gpu_layers=0  # CPU-only by default
        )

    def _log_interaction(self, user_input: str, response: str):
        entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "user": user_input,
            "sue": response
        }
        self.json_memory.append_log(entry)

    def _call_llm(self, prompt: str) -> str:
        out = self.llm(
            prompt,
            max_tokens=512,
            temperature=0.7,
            top_p=0.95,
            stop=["User:", "SUE:"]
        )
        text = out["choices"][0]["text"]
        return text.strip()

    def handle(self, user_input: str, channel: str = "user") -> str:
        user_input = user_input.strip()

        # Dev mode commands
        if channel == "dev" or user_input.startswith("!dev"):
            cmd = user_input.replace("!dev", "", 1).strip()
            return self.devmode.execute(cmd)

        low = user_input.lower().strip()

        if low == "memory status":
            return self._memory_status()

        if low.startswith("remember "):
            note = user_input[len("remember "):].strip()
            self.json_memory.save_fact(note)
            return f"I’ve saved that to long-term memory: {note}"

        # retrieve context
        context_snippets = self.vector_memory.search_relevant(user_input, k=5)
        context_text = "\n".join([f"- {c['text']}" for c in context_snippets])

        prompt = (
            "You are S.U.E., a local autonomous assistant built by Josh.\n"
            "Respond clearly, grounded, and avoid inventing unverifiable facts.\n\n"
            "Conversation:\n"
            f"User: {user_input}\n\n"
            "Relevant memory context:\n"
            f"{context_text}\n\n"
            "SUE:"
        )

        raw_response = self._call_llm(prompt)
        filtered_response = self.hf.filter(user_input, raw_response)
        self._log_interaction(user_input, filtered_response)

        # index interaction
        self.vector_memory.add_document(
            text=user_input,
            metadata={"type": "user_message", "timestamp": datetime.utcnow().isoformat() + "Z"}
        )
        self.vector_memory.add_document(
            text=filtered_response,
            metadata={"type": "sue_response", "timestamp": datetime.utcnow().isoformat() + "Z"}
        )

        return filtered_response

    def _memory_status(self) -> str:
        stats = self.vector_memory.stats()
        return (
            "Memory Status:\n"
            f"- JSON logs: {self.json_memory.count_logs()} entries\n"
            f"- Vector docs: {stats.get('docs', 0)}\n"
            f"- Last rebuild: {self.json_memory.get_last_rebuild_time()}"
        )
