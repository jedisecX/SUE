import json
import os
from typing import List, Dict

from llama_cpp import Llama


class VectorMemory:
    """Vector store using llama.cpp embedding API and a simple JSON file."""

    def __init__(self, path: str, model_path: str = "models/embedding.gguf"):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)

        if not os.path.exists(model_path):
            raise RuntimeError(f"Embedding model not found at {model_path}. Place a GGUF embedding model there.")

        # embedding-only model
        self.model = Llama(
            model_path=model_path,
            embedding=True,
            n_threads=6
        )

        if not os.path.exists(self.path):
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({"docs": []}, f)

    def _load(self):
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save(self, data):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _embed(self, text: str):
        out = self.model.embed(text)
        return out["data"][0]["embedding"]

    def add_document(self, text: str, metadata: Dict):
        data = self._load()
        emb = self._embed(text)
        data["docs"].append({
            "text": text,
            "metadata": metadata,
            "embedding": emb
        })
        self._save(data)

    def search_relevant(self, query: str, k: int = 5) -> List[Dict]:
        data = self._load()
        docs = data.get("docs", [])
        if not docs:
            return []

        qv = self._embed(query)

        import math
        def cos_sim(a, b):
            dot = sum(x * y for x, y in zip(a, b))
            na = math.sqrt(sum(x * x for x in a))
            nb = math.sqrt(sum(x * x for x in b))
            return dot / (na * nb + 1e-9)

        scored = []
        for d in docs:
            s = cos_sim(qv, d["embedding"])
            scored.append((s, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [d for _, d in scored[:k]]

    def stats(self) -> Dict:
        data = self._load()
        return {"docs": len(data.get("docs", []))}
