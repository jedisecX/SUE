from typing import Any


class HallucinationFilter:
    """Simple hallucination filter placeholder."""

    def __init__(self, json_memory: Any, vector_memory: Any):
        self.json_memory = json_memory
        self.vector_memory = vector_memory

    def filter(self, user_input: str, raw_response: str) -> str:
        safe = raw_response
        if "100%" in safe or "guaranteed" in safe:
            safe += "\n\n[Note: Some details may require verification.]"
        return safe
