from datetime import datetime


class CognitiveRebuilder:
    """Nightly / on-command memory rebuild hook."""

    def __init__(self, settings: dict, dispatcher):
        self.settings = settings
        self.dispatcher = dispatcher

    def run_rebuild(self):
        self.dispatcher.json_memory.set_last_rebuild_time()
        print(f"[SUE] Cognitive Rebuild completed at {datetime.utcnow().isoformat()}Z")
