class EmotionEngine:
    """Simple sentiment-to-color mapper for UI accenting."""

    def classify(self, text: str) -> str:
        t = text.lower()
        if any(x in t for x in ["angry", "mad", "furious", "pissed"]):
            return "red"
        if any(x in t for x in ["sad", "depressed", "lonely", "tired"]):
            return "blue"
        if any(x in t for x in ["love", "happy", "joy", "good"]):
            return "green"
        return "matrix"
