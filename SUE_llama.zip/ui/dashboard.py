from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from ui.emotion_engine import EmotionEngine


class Dashboard:
    def __init__(self, dispatcher, settings: dict):
        self.dispatcher = dispatcher
        self.settings = settings
        self.console = Console()
        self.emotions = EmotionEngine()

    def print_banner(self):
        title = self.settings.get("name", "S.U.E.")
        banner_text = f"{title} — Sentient Unified Entity\nLocal llama.cpp-powered assistant"
        self.console.print(Panel(banner_text, title="SUE", subtitle="Jedi Security"))

    def get_user_input(self, prompt: str = None) -> str:
        if prompt is None:
            prompt = "[bold cyan]You[/] > "
        return Prompt.ask(prompt)

    def display_response(self, text: str):
        color_mode = self.emotions.classify(text)
        if color_mode == "red":
            style = "bold red"
        elif color_mode == "blue":
            style = "bold blue"
        elif color_mode == "green":
            style = "bold green"
        else:
            style = "bold bright_green on black"

        self.console.print(Panel(text, style=style, title="SUE"))
