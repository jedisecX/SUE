import feedparser
from datetime import datetime
from typing import Dict, Any


class RSSProcessor:
    def __init__(self, settings: Dict[str, Any], feeds_cfg: Dict[str, Any], dispatcher):
        self.settings = settings
        self.feeds_cfg = feeds_cfg
        self.dispatcher = dispatcher
        self.feeds = feeds_cfg.get("default_feeds", [])
        self.tags = feeds_cfg.get("tags", {})
        self.articles = []

    def refresh_all_feeds(self):
        self.articles = []
        for url in self.feeds:
            try:
                feed = feedparser.parse(url)
                for entry in feed.entries:
                    self.articles.append({
                        "title": entry.get("title", ""),
                        "summary": entry.get("summary", ""),
                        "link": entry.get("link", ""),
                        "published": entry.get("published", ""),
                        "source": url
                    })
            except Exception as e:
                print(f"[SUE] RSS error for {url}: {e}")

    def generate_digest(self):
        if not self.articles:
            print("[SUE] No RSS articles to digest.")
            return

        headlines = [a["title"] for a in self.articles[:20]]
        text = "\n".join(f"- {h}" for h in headlines)
        self.dispatcher.vector_memory.add_document(
            text=text,
            metadata={
                "type": "rss_digest",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        )
        print("[SUE] RSS digest stored in memory.")
