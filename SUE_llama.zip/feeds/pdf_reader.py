import os
from typing import List

import PyPDF2


class PDFReader:
    """Reads PDFs and indexes pages into vector memory."""

    def __init__(self, dispatcher, pdf_root: str = "pdfs"):
        self.dispatcher = dispatcher
        self.pdf_root = pdf_root
        os.makedirs(self.pdf_root, exist_ok=True)

    def ingest_pdf(self, path: str, tags: List[str] = None):
        if not os.path.exists(path):
            print(f"[SUE] PDF not found: {path}")
            return

        with open(path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            pages_text = []
            for i, page in enumerate(reader.pages):
                try:
                    txt = page.extract_text() or ""
                except Exception:
                    txt = ""
                pages_text.append((i, txt))

        for page_idx, txt in pages_text:
            if not txt.strip():
                continue
            self.dispatcher.vector_memory.add_document(
                text=txt,
                metadata={
                    "type": "pdf_page",
                    "file": os.path.basename(path),
                    "page": page_idx,
                    "tags": tags or []
                }
            )

        print(f"[SUE] Ingested PDF: {path}")
